const AWS = require('aws-sdk');

const sns = new AWS.SNS();

exports.handler = async (event) => {
    try {
        console.log("Event: ", event);

        const { email, topicArn } = event;

        const subject = 'Welcome back to dalVacationHome';
        const message = `Hello ${email},\n\nYou have successfully signed in!`;

        const publishParams = {
            TopicArn: topicArn,
            Message: message,
            Subject: subject
        };

        await sns.publish(publishParams).promise();
        console.log(`Email sent to ${email}`);

        return {
            status: 200,
            body: JSON.stringify({message: "Email sent successfully."})
        };
    } catch (error) {
        console.log("Error: ", error);
        return {
            status: 500,
            body: JSON.stringify({message:error})
        }
    }


};

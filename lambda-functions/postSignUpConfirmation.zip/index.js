const AWS = require('aws-sdk');
const { DynamoDBClient, PutItemCommand } = require('@aws-sdk/client-dynamodb');

const dynamodb = new DynamoDBClient({ region: 'us-east-1' });

const cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider();
const sns = new AWS.SNS();

exports.handler = async (event) => {
    try {
        console.log("Event: ", event);

        const userPoolId = event.userPoolId;
        const userName = event.userName;
        const { email } = event.request.userAttributes;
        const userRole = event.request.userAttributes['custom:userRole'];

        let groupName;

        switch (userRole) {
            case 'admin0':
                groupName = 'Admin';
                break;
            case 'regular':
                groupName = 'Regular';
                break;
            default:
                return {
                    statusCode: 400,
                    body: JSON.stringify({ message: 'Invalid user role' })
                };
        }

        const paramsForUserDetails = {
            TableName: 'UserDetails',
            Item: {
                userId: { S: email },
                userRole: { S: userRole },
                timestamp: { N: Date.now().toString() },
            },
        };

        const command = new PutItemCommand(paramsForUserDetails);
        await dynamodb.send(command);

        console.log("Use Details Added Successfully to Dynamodb.");

        const paramsForUserGroup = {
            GroupName: groupName,
            UserPoolId: userPoolId,
            Username: userName
        };

        await cognitoIdentityServiceProvider.adminAddUserToGroup(paramsForUserGroup).promise();

        console.log("User added successfully to UserGroup.");

        const { clue, answer } = getClue();

        const paramsForCeaserCipher = {
            TableName: "ceaserCipher",
            Item: {
                userId: { S: email },
                clue: { S: clue },
                answer: { S: answer },
                timestamp: { N: Date.now().toString() },
            }
        }

        await dynamodb.send(new PutItemCommand(paramsForCeaserCipher));

        console.log("CeaserCipher challenge added successfully.");

        const subject = 'Welcome to dalVacationHome';
        const message = `Hello ${email}, Thank you for registering!`;

        const topicArn = 'arn:aws:sns:us-east-1:774821680662:authentication';

        const publishParams = {
            TopicArn: topicArn,
            Message: message,
            Subject: subject
        };
        const res = await sns.publish(publishParams).promise();
        console.log("After email send : ", res.data);
        console.log(`Email sent to ${email}`);

        return event;
    } catch (error) {
        console.log("Error: ", error);
        event.response = {
            errorMessage: `Failed to send email: ${error.message}`
        };

        throw new Error(`Failed to send email: ${error.message}`);
    }


};

const getClue = () => {

    const words = [
        'HELLO', 'WORLD', 'SECURE', 'DYNAMODB', 'LAMBDA', 'ENCRYPT',
        'SERVERLESS', 'DATABASE', 'SECURITY', 'COMPUTER', 'APPLICATION',
        'FUNCTION', 'INTERNET', 'PASSWORD', 'NETWORK'
    ];

    const number = Math.floor(Math.random() * words.length);
    const selectedWord = words[number];
    const shift = Math.floor(Math.random() * 25) + 1;

    const clue = `Encrypt '${selectedWord}' with a shift of ${shift}`
    console.log("Clue : ",clue)

    const encryptedWord = selectedWord
        .split('')
        .map(char => {
            const code = char.charCodeAt(0);
            if (code >= 65 && code <= 90) {
                return String.fromCharCode(((code - 65 + shift) % 26) + 65);
            } else if (code >= 97 && code <= 122) {
                return String.fromCharCode(((code - 97 + shift) % 26) + 97);
            }
            return char;
        })
        .join('');
    
    console.log("EncryptedWord : ", encryptedWord);
    
    return {
        clue,
        answer: encryptedWord
    }

}
